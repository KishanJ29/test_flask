import os
from flask import Flask, render_template, request, jsonify, session
from chatbot_backend import chatbot
from dotenv import load_dotenv

load_dotenv()



app = Flask(__name__)
app.secret_key = os.getenv('FLASK_SECRET_KEY')

@app.route('/')
def index():
    session.clear()  # Clear session on new conversation
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    query = request.json['query']
    
    # Initialize session state if not already set
    if 'conversation_state' not in session:
        session['conversation_state'] = {}
    
    # Process user input and manage conversation state
    response, session['conversation_state'] = chatbot.chatbot_response(query, session['conversation_state'])
    
    return jsonify({'response': response})

if __name__ == '__main__':
    app.secret_key = 'super secret key'
    app.config['SESSION_TYPE'] = 'filesystem'

    # sess.init_app(app)
    app.run(debug=True)