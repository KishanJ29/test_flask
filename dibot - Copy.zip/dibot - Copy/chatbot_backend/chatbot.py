import dashboard_dax_fetch as dax
import power_bi_api as pbi
def queries_list():
    return [
        "total manhours by registers",
        "total manhours for Aug 2024",
        "project progress by week",
        # Add more questions here...
    ]

def chatbot_response(query, conversation_state):
    if 'greeted' not in conversation_state:
        conversation_state['greeted'] = True
        return "Hi there! What project and discipline are you asking about?", conversation_state
    
    if 'project' not in conversation_state:
        conversation_state['project'] = query
        return "Thanks! And what discipline?", conversation_state
    
    if 'discipline' not in conversation_state:
        conversation_state['discipline'] = query
        recommended_queries = queries_list()
        return f"What would you like to know? Here are some suggestions: {', '.join(recommended_queries)}", conversation_state
    
    # Handle specific queries
    if 'selected_query' not in conversation_state:
        conversation_state['selected_query'] = query.lower()
        
        if conversation_state['selected_query'] == "total manhours by registers":
            return "Please specify the register.", conversation_state
        
        if conversation_state['selected_query'] == "total manhours for aug 2024":
            return "Please specify the date range.", conversation_state
        
        # For other queries, just confirm the request
        return f"Fetching information on {conversation_state['selected_query']}.", conversation_state
    
    # Handle additional parameter input
    if 'selected_query' in conversation_state:
        if conversation_state['selected_query'] == "total manhours by registers":
            return f"Fetching total manhours for register {query}.", conversation_state
        
        if conversation_state['selected_query'] == "total manhours for aug 2024":
            return f"Fetching total manhours for the date range {query}.", conversation_state

    return "I'm sorry, I didn't understand that.", conversation_state

def powerbi_query(query, conversation_state):
    pass

def chatbot_main(query):
    name, dax_result = dax.main(query)
    workspace_id = pbi.WORKSPACE_ID
    dataset_id = pbi.DATASET_ID
    print('Name','Dax Result',name, dax_result)
    response = pbi.execute_dax_query(workspace_id, dataset_id, dax_result)
    print(response)

    

if __name__ == "__main__":
    
    query = input("Enter your query: ")
    chatbot_main(query=query)

