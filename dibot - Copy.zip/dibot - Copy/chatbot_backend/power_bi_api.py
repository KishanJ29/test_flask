import requests
import msal
import json
import os
import pandas as pd

from dotenv import load_dotenv
load_dotenv()

# Azure AD and Power BI API configuration
CLIENT_ID = os.getenv('POWERBI_CLIENT_ID')
TENANT_ID = os.getenv('POWERBI_TENANT_ID')
CLIENT_SECRET = os.getenv('POWERBI_CLIENT_SECRET')
WORKSPACE_ID = os.getenv('POWERBI_WORKSPACE_ID')
DATASET_ID = os.getenv('POWERBI_DATASET_ID')

AUTHORITY = f'https://login.microsoftonline.com/{TENANT_ID}'
SCOPE = ['https://analysis.windows.net/powerbi/api/.default']
POWER_BI_API_URL = 'https://api.powerbi.com/v1.0/myorg'

# Create a MSAL confidential client
client = msal.ConfidentialClientApplication(
    CLIENT_ID,
    authority=AUTHORITY,
    client_credential=CLIENT_SECRET
)

# Acquire a token
token_response = client.acquire_token_for_client(scopes=SCOPE)
access_token = token_response['access_token']

# Function to get the dataset metadata
def get_dataset_metadata(workspace_id, dataset_id):
    url = f'{POWER_BI_API_URL}/groups/{workspace_id}/datasets/{dataset_id}'
    headers = {
        'Authorization': f'Bearer {access_token}'
    }
    response = requests.get(url, headers=headers)
    return response.json()

# Function to execute a DAX query
def execute_dax_query(workspace_id, dataset_id, query):
    url = f'{POWER_BI_API_URL}/groups/{workspace_id}/datasets/{dataset_id}/executeQueries'
    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'application/json'
    }
    # query = '"""'+"Evaluate "+ query+'"""'
    payload = {
        "queries": [{
            "query": query.strip()
        }],
        "serializerSettings": {
            "includeNulls": True
        }
    }
    print("PAYLOAD SENT",payload)
    response = requests.post(url, headers=headers, data=json.dumps(payload))
    table_data = response.json().get('results')[0].get('tables')[0].get('rows')
    table = pd.DataFrame(table_data)
    return table.head(5)

# # Retrieve dataset metadata
# dataset_metadata = get_dataset_metadata(WORKSPACE_ID, DATASET_ID)
# print(json.dumps(dataset_metadata, indent=4))

# # Execute a DAX query
# query = "EVALUATE SUMMARIZE('Sales', 'Sales'[Product], 'Sales'[Amount])"
# query1= 'EVALUATE SUMMARIZE(FILTER(Overall,Overall[DISCIPLINE]="COMMISSIONING"&&Overall[Cutoff]>DATE(2023,11,01)),Overall[DISCIPLINE],Overall[Month-yr],"Manhours",SUM(Overall[Value]))'
# query_result = execute_dax_query(WORKSPACE_ID, DATASET_ID, query1)
# print(json.dumps(query_result, indent=4))
