import os
from dotenv import load_dotenv

load_dotenv('C:\Chatabot-LLM\chatbot-implemenation\.env')


print( 'FLASK SECRET',os.getenv('FLASK_SECRET'))